package application;

public interface FileWriterFactory {
	public void writeFile(String data, String fileType);
}

