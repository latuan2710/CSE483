package application;

import features.ui.FileWriterUI;

public class Main {
    public static void main(String[] args) {
        FileWriterUI ui = new FileWriterUI();
        ui.setVisible(true);
    }
}
