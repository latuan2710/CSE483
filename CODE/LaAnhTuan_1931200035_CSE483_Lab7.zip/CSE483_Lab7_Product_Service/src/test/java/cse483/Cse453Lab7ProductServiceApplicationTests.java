package cse483;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cse453Lab7ProductServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
