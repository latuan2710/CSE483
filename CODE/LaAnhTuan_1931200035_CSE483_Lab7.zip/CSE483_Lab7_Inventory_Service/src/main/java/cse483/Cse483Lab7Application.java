package cse483;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cse483Lab7Application {

    public static void main(String[] args) {
        SpringApplication.run(Cse483Lab7Application.class, args);
    }

}
