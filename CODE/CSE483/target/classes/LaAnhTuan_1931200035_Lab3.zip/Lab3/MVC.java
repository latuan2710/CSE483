package Lab3;

import Lab3.Controller.Controller;

public class MVC {

	public static void main(String[] args) throws CloneNotSupportedException {
		Controller controller = new Controller();

		controller.showMenu();
	}

}
