package Lab3.Model;

public enum AccountType {
	SAVINGS, CHECKING, LOAN;
}
