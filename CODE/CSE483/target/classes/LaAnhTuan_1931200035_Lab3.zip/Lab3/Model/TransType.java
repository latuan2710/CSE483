package Lab3.Model;

public enum TransType {
	DEPOSIT, WITHDRAW;
}
